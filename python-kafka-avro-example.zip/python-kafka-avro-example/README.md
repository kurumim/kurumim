### Python kafka avro example

`kafka-consumer-groups  --describe --group group2  --bootstrap-server localhost:9092`