from time import sleep
import sys
from confluent_kafka import avro
from confluent_kafka.avro import AvroProducer

value_schema = avro.load('schema/producer/ValueSchema.avsc')
##key_schema = avro.load('schema/producer/KeySchema.avsc')
##key = {"name": "Rathi"}
value = {"name": "Value", "favorite_number": 10, "favorite_color": "green", "age": 25}

avroProducer = AvroProducer(
    {'bootstrap.servers': 'localhost:9092', 'schema.registry.url': 'http://127.0.0.1:8081'}, default_value_schema=value_schema)

while True:
    tmp = input("message: ")
    msg = {"message":tmp, "country": "BR", "requestTraceId": "123456"}
    avroProducer.produce(topic=sys.argv[1], value=msg, value_schema=value_schema)

avroProducer.flush(10)
